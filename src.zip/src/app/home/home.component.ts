import { Component, Pipe } from '@angular/core';
import { EmpServiceService } from '../emp-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})



export class HomeComponent {

  form:any={id:null,name:null,projectsdone:null,dept:null}
  result:any;
  content?: string;
  message?:string;
  now: any;
  result1 = [];

  id?:any;
  name: any;
  projectsdone: any;
  dept: any;
  showSection2: boolean= false;
  

  constructor(private empService: EmpServiceService,private router:Router ) { }

  ngOnInit(): void {
  
  }

  onSubmitAdd(){
    this.showSection2 = false;
      const data = {
        name: this.name,
        projectsdone: this.projectsdone,
        dept: this.dept
      };
      if(this.name==null || this.projectsdone==null||this.dept==null)
      alert("Fields cannot be empty!")
    else{
    this.empService.SetEmployee(data).subscribe(data=>{console.log(data);
    this.result=data;
    console.log(this.result);
    return this.result;
    },
    err => {
      this.content = JSON.parse(err.error).message;
    }
    )
  }
  }

  onSubmitSearch(){
    this.showSection2 = false;
    if(this.name==null)
      alert("Please enter the Name to search")
    else{
      this.empService.SearchEmployee(this.name).subscribe(data=>{console.log(data);
        //this.result = data.json();
        this.result = Array.of(data);
       // this.result=data;
        console.log(this.result);
        this.showSection2 = true;
        return this.result;
    },
    err => {
      this.content = JSON.parse(err.error).message;
    }
    )
   }
  }

  onSubmitView(){
    this.empService.GetAllEmployees().subscribe(data=>{console.log(data);
    this.result=data;
    console.log(this.result);
    this.showSection2 = true;
    return this.result;
    },
    err => {
      this.content = JSON.parse(err.error).message;
    }
    )

  }

  reloadPage(): void {
    window.location.reload();
  }

}
