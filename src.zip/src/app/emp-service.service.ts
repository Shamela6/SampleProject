import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

const addEmp= 'http://localhost:8081/employee.com/addEmployee';
const getEmp= 'http://localhost:8081/employee.com/employeeDetails';
const searchEmp= 'http://localhost:8081/employee.com/filterByName/';

@Injectable({
  providedIn: 'root'
})
export class EmpServiceService {

  constructor(private http:HttpClient) { }

  SetEmployee(data:any): Observable<any>{
    return this.http.post(addEmp,data);
  }

  GetAllEmployees(): Observable<any>{
    return this.http.get(getEmp);
  }

  SearchEmployee(name:any): Observable<any>{
    return this.http.get(searchEmp+name);
  }
}
